import { router, json, error } from '@appdeploy/sdk';
import { ai } from '@appdeploy/sdk';

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ message: 'Success' })],
  'POST /api/automate': [async ({ body }) => {
    const input = body as { text?: string };
    const text = input?.text?.trim();
    if (!text) return error('Document text is required', 400);
    if (text.length > 30000) return error('Document text is too long. Please provide up to 30,000 characters.', 413);
    try {
      const result = await ai.extract({
        content: text,
        prompt: 'Analyze this business document. Extract the most useful operational information. Do not invent facts. If a field is not present, return an empty list or a concise unknown value.',
        schema: { type: 'object', properties: { documentType: { type: 'string' }, title: { type: 'string' }, parties: { type: 'array', items: { type: 'string' } }, dates: { type: 'array', items: { type: 'string' } }, amounts: { type: 'array', items: { type: 'string' } }, keyFacts: { type: 'array', items: { type: 'string' } }, risks: { type: 'array', items: { type: 'string' } }, actionItems: { type: 'array', items: { type: 'string' } }, summary: { type: 'string' } }, required: ['documentType','title','parties','dates','amounts','keyFacts','risks','actionItems','summary'] },
        maxRetries: 2,
        maxTokens: 1200,
        thinkingMode: 'FAST'
      });
      return json({ result: result.data });
    } catch (err) {
      console.error('AI document automation failed', err);
      return error('AI document processing failed', 502);
    }
  }]
});
