import { useMemo, useState } from 'react';
import { api } from '@appdeploy/client';
import { FileText, Sparkles, ShieldCheck, ArrowRight, Upload, CheckCircle2, Copy, RotateCcw, Menu, X, Zap, Brain, ListChecks } from 'lucide-react';

const sample = `INVOICE\nAcme Medical Supplies Ltd.\nInvoice Number: INV-2048\nInvoice Date: 08 September 2026\nDue Date: 22 September 2026\nCustomer: Greenfield Clinic\nTotal Amount: NGN 485,000\nPayment Terms: Net 14\nItems: Examination gloves, surgical masks, disposable gowns\nNotes: Payment should be made by bank transfer. Late payments may attract a service charge.`;

type Result = { documentType: string; title: string; parties: string[]; dates: string[]; amounts: string[]; keyFacts: string[]; risks: string[]; actionItems: string[]; summary: string };

export default function App() {
  const [text, setText] = useState('');
  const [fileName, setFileName] = useState('');
  const [result, setResult] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const chars = useMemo(() => text.length, [text]);

  const loadSample = () => { setText(sample); setFileName('sample-invoice.pdf'); setResult(null); setError(''); };
  const onFile = (file?: File) => {
    if (!file) return;
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) { setError('Please choose a PDF file.'); return; }
    setFileName(file.name);
    setError('');
  };
  const runAutomation = async () => {
    if (!text.trim()) { setError('Paste the document text or load the demo invoice first.'); return; }
    setBusy(true); setError('');
    try {
      const response = await api.post('/api/automate', { text });
      setResult(response.data.result as Result);
    } catch (e) {
      setError('The AI service could not process this document. Please try again.');
    } finally { setBusy(false); }
  };
  const copySummary = async () => { if (result) await navigator.clipboard?.writeText(result.summary); };

  return <div className='min-h-screen bg-slate-950 text-slate-100'>
    <header className='sticky top-0 z-20 border-b border-white/10 bg-slate-950/90 backdrop-blur'>
      <div className='mx-auto flex max-w-7xl items-center justify-between px-5 py-4'>
        <div className='flex items-center gap-3'><div className='grid h-10 w-10 place-items-center rounded-xl bg-cyan-400 text-slate-950'><Brain size={22}/></div><div><div className='font-bold tracking-tight'>AI PDF Automation</div><div className='text-xs text-slate-400'>Document Intelligence Workspace</div></div></div>
        <nav className='hidden items-center gap-7 text-sm text-slate-300 md:flex'><a href='#workspace' className='hover:text-white'>Workspace</a><a href='#workflow' className='hover:text-white'>How it works</a><a href='#capabilities' className='hover:text-white'>Capabilities</a></nav>
        <button className='md:hidden' onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X/> : <Menu/>}</button>
      </div>
      {mobileOpen && <div className='border-t border-white/10 px-5 py-4 md:hidden'><a href='#workspace' className='block py-2'>Workspace</a><a href='#workflow' className='block py-2'>How it works</a><a href='#capabilities' className='block py-2'>Capabilities</a></div>}
    </header>

    <main>
      <section className='relative overflow-hidden'><div className='absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(34,211,238,.16),transparent_35%),radial-gradient(circle_at_20%_30%,rgba(99,102,241,.12),transparent_30%)]'/><div className='relative mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-[1.05fr_.95fr] lg:items-center'>
        <div><div className='mb-5 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-1.5 text-xs font-semibold text-cyan-300'><Sparkles size={14}/> AI-powered document workflows</div><h1 className='max-w-3xl text-4xl font-black leading-tight tracking-tight sm:text-6xl'>Turn document text into <span className='text-cyan-300'>structured intelligence.</span></h1><p className='mt-6 max-w-2xl text-lg leading-8 text-slate-400'>Extract key fields, summarize documents, identify risks, and create action items in seconds — built as a practical automation workflow for modern businesses.</p><div className='mt-8 flex flex-wrap gap-3'><a href='#workspace' className='inline-flex items-center gap-2 rounded-xl bg-cyan-400 px-5 py-3 font-bold text-slate-950'>Open workspace <ArrowRight size={17}/></a><button onClick={loadSample} className='rounded-xl border border-white/10 px-5 py-3 font-semibold text-slate-200 hover:bg-white/5'>Try demo document</button></div><div className='mt-8 flex flex-wrap gap-5 text-sm text-slate-400'><span className='flex items-center gap-2'><ShieldCheck size={16} className='text-cyan-300'/> Structured extraction</span><span className='flex items-center gap-2'><Zap size={16} className='text-cyan-300'/> Fast workflow</span><span className='flex items-center gap-2'><CheckCircle2 size={16} className='text-cyan-300'/> Business-ready output</span></div></div>
        <div className='rounded-3xl border border-white/10 bg-white/[.04] p-5 shadow-2xl shadow-cyan-950/30'><div className='mb-5 flex items-center justify-between'><div><div className='font-semibold'>Automation preview</div><div className='text-xs text-slate-500'>Invoice → structured data</div></div><span className='rounded-full bg-emerald-400/10 px-2.5 py-1 text-xs text-emerald-300'>Ready</span></div><div className='space-y-3'>{[['Document type','Invoice'],['Amount','NGN 485,000'],['Due date','22 Sep 2026'],['Risk flags','1 review'],['Action items','3 generated']].map(([a,b])=><div key={a} className='flex items-center justify-between rounded-2xl border border-white/5 bg-slate-900/70 p-4'><span className='text-sm text-slate-500'>{a}</span><span className='text-sm font-semibold'>{b}</span></div>)}</div></div>
      </div></section>

      <section id='workspace' className='mx-auto max-w-7xl px-5 py-16'><div className='mb-8'><p className='text-sm font-bold uppercase tracking-widest text-cyan-300'>Document workspace</p><h2 className='mt-2 text-3xl font-bold'>Process a document</h2><p className='mt-2 text-slate-400'>Upload a PDF to identify it, then paste its extracted text for AI processing. The demo keeps document contents in the current session.</p></div>
        <div className='grid gap-6 lg:grid-cols-2'>
          <div className='rounded-3xl border border-white/10 bg-white/[.04] p-5'><label className='mb-3 block text-sm font-semibold'>1. Select PDF</label><label className='flex cursor-pointer items-center justify-center gap-3 rounded-2xl border border-dashed border-white/15 bg-slate-900/50 px-5 py-8 text-center hover:border-cyan-400/40'><input type='file' accept='.pdf,application/pdf' className='hidden' onChange={e => onFile(e.target.files?.[0])}/><Upload className='text-cyan-300'/><span><b>{fileName || 'Choose a PDF document'}</b><span className='mt-1 block text-xs text-slate-500'>PDF only · up to your browser upload limit</span></span></label><div className='mt-5 flex items-center justify-between'><label className='text-sm font-semibold'>2. Document text</label><button onClick={loadSample} className='text-xs font-semibold text-cyan-300 hover:text-cyan-200'>Load sample</button></div><textarea value={text} onChange={e=>setText(e.target.value)} placeholder='Paste the text extracted from your PDF here...' className='mt-3 h-64 w-full resize-none rounded-2xl border border-white/10 bg-slate-950 p-4 text-sm leading-6 outline-none placeholder:text-slate-600 focus:border-cyan-400/40'/><div className='mt-2 text-right text-xs text-slate-600'>{chars.toLocaleString()} characters</div><button disabled={busy} onClick={runAutomation} className='mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-cyan-400 px-5 py-3 font-bold text-slate-950 disabled:cursor-not-allowed disabled:opacity-50'>{busy ? 'Processing with AI…' : <><Sparkles size={17}/> Automate document</>}</button>{error && <div className='mt-3 rounded-xl border border-rose-400/20 bg-rose-400/10 p-3 text-sm text-rose-200'>{error}</div>}</div>

          <div className='rounded-3xl border border-white/10 bg-white/[.04] p-5'><div className='mb-5 flex items-center justify-between'><div><div className='text-sm font-semibold'>3. AI results</div><div className='text-xs text-slate-500'>Structured output generated from your text</div></div>{result && <button onClick={()=>setResult(null)} className='flex items-center gap-1 text-xs text-slate-400 hover:text-white'><RotateCcw size={14}/> Reset</button>}</div>{!result ? <div className='grid h-[520px] place-items-center rounded-2xl border border-white/5 bg-slate-900/40 p-8 text-center'><div><div className='mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-cyan-400/10 text-cyan-300'><ListChecks/></div><h3 className='mt-4 font-bold'>Your structured results appear here</h3><p className='mx-auto mt-2 max-w-sm text-sm leading-6 text-slate-500'>Run the automation to extract document type, parties, dates, amounts, key facts, risks, and action items.</p></div></div> : <div className='space-y-4'><div className='rounded-2xl bg-cyan-400/10 p-4'><div className='text-xs uppercase tracking-wider text-cyan-300'>Document type</div><div className='mt-1 text-xl font-bold'>{result.documentType}</div><div className='mt-1 text-sm text-slate-400'>{result.title}</div></div><div className='grid gap-3 sm:grid-cols-2'>{[['Parties',result.parties],['Dates',result.dates],['Amounts',result.amounts],['Key facts',result.keyFacts],['Risks',result.risks],['Action items',result.actionItems]].map(([label,items])=><div key={label as string} className='rounded-2xl border border-white/5 bg-slate-900/60 p-4'><div className='text-xs font-semibold uppercase tracking-wider text-slate-500'>{label as string}</div><ul className='mt-2 space-y-1.5 text-sm text-slate-300'>{(items as string[]).length ? (items as string[]).map((x,i)=><li key={i}>• {x}</li>) : <li className='text-slate-600'>None detected</li>}</ul></div>)}</div><div className='rounded-2xl border border-white/5 bg-slate-900/60 p-4'><div className='flex items-center justify-between'><div className='text-xs font-semibold uppercase tracking-wider text-slate-500'>Executive summary</div><button onClick={copySummary} className='flex items-center gap-1 text-xs text-cyan-300'><Copy size={13}/> Copy</button></div><p className='mt-2 text-sm leading-6 text-slate-300'>{result.summary}</p></div></div>}</div>
        </div>
      </section>

      <section id='workflow' className='border-y border-white/5 bg-white/[.02]'><div className='mx-auto max-w-7xl px-5 py-16'><div className='mb-10 text-center'><p className='text-sm font-bold uppercase tracking-widest text-cyan-300'>Workflow</p><h2 className='mt-2 text-3xl font-bold'>From document to decision</h2></div><div className='grid gap-4 md:grid-cols-3'>{[['01','Capture','Select a PDF and prepare its text for processing.'],['02','Understand','AI extracts structured fields and identifies important facts and risks.'],['03','Act','Turn the results into summaries and clear next steps for your team.']].map(([n,t,d])=><div key={n} className='rounded-3xl border border-white/10 bg-slate-950/70 p-6'><div className='text-sm font-black text-cyan-300'>{n}</div><h3 className='mt-5 text-xl font-bold'>{t}</h3><p className='mt-2 leading-7 text-slate-500'>{d}</p></div>)}</div></div></section>

      <section id='capabilities' className='mx-auto max-w-7xl px-5 py-16'><div className='grid gap-5 md:grid-cols-3'>{[['Structured extraction','Convert unstructured document text into useful fields and lists.'],['Risk detection','Surface clauses, missing information, deadlines, and items that deserve review.'],['Operational summaries','Create concise summaries and action items that teams can use immediately.']].map(([t,d])=><div key={t} className='rounded-3xl border border-white/10 p-6'><div className='mb-4 grid h-11 w-11 place-items-center rounded-xl bg-cyan-400/10 text-cyan-300'><Sparkles size={20}/></div><h3 className='font-bold'>{t}</h3><p className='mt-2 text-sm leading-6 text-slate-500'>{d}</p></div>)}</div></section>
    </main>
    <footer className='border-t border-white/10 px-5 py-8'><div className='mx-auto flex max-w-7xl flex-col justify-between gap-3 text-sm text-slate-500 md:flex-row'><span>AI PDF Automation · Document Intelligence</span><span>Portfolio project by Maxwell Kenechukwu Nwazue · Nigeria (GMT+1)</span></div></footer>
  </div>;
}
